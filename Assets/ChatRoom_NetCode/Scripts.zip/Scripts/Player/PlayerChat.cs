using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using CustomInspector;
using System;
using Unity.VisualScripting;
using UnityEditor.VersionControl;

[Serializable]
public class PlayerChat : NetworkBehaviour
{
    [SerializeField] private int PlayerId;

    [SerializeField] private Dictionary<int, List<string>> chatHistory;

    private void Start() {
        DontDestroyOnLoad(this);
    }

    private void Update() {
        if(!IsOwner) return;


    }
    
    public override void OnNetworkSpawn() {
        RegisterMyself();
    }
    

    [HorizontalLine("Debug")]

    [Button(nameof(SendMessgaeDebug),true)]
    [SerializeField]private int receiveId;
    [SerializeField]private string messsage;
    public void SendMessgaeDebug(int a) {
        Message message=(new Message(this.PlayerId, receiveId, messsage));
        if (!IsOwner) {
            return;
        }
        string tmp = JsonUtility.ToJson(message);
        if (IsServer) {
            Debug.Log(tmp);
            PlayerChatManager.instance.SendMessageChat(tmp);
        }
        else {
            SendMessageServerRpc(tmp);
        }
    }

    private bool hasRigister = false;
    private void RegisterMyself() {
        if (hasRigister||PlayerChatManager.instance == null) {
            return;
        }
        hasRigister=true;
        PlayerChatManager.instance.Register(this);
        chatHistory = new Dictionary<int, List<string>>();
    }

    
    public void SetPlayerId(int id) {
        this.PlayerId=id;
    }

    public int GetPlayerId() {
        return this.PlayerId;
    }

    [ServerRpc]
    public void SendMessageServerRpc(string message) {
        Debug.Log(message);
        PlayerChatManager.instance.SendMessageChat(message);
    }

    public void GetMessage(string tmp) {
        //only the owner can get the message;
        if (!IsOwner) {
            return;
        }
        Message message=JsonUtility.FromJson<Message>(tmp);
        chatHistory[message.sendPlayerId].Add(message.message);

        Debug.Log("Receive a message from:" +message.sendPlayerId+", and the content is:"+message.message);
    }
}
