using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NetworkModeManager : MonoBehaviour
{
    [SerializeField] private Button S;
    [SerializeField] private Button H;
    [SerializeField] private Button C;

    private void Start() {
        S.onClick.AddListener(() =>
        {
            NetworkManager.Singleton.StartServer();
            Transition();
        });

        H.onClick.AddListener(() =>
        {

            NetworkManager.Singleton.StartHost();
            Transition();
        });

        C.onClick.AddListener(() =>
        {

            NetworkManager.Singleton.StartClient();
            Transition();
        });
    }

    private void Transition() {
        SceneManager.LoadSceneAsync("Example");
    }
}
